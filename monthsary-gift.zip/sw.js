const CACHE_NAME = 'monthsary-gift-v1';
const urlsToCache = [
  './',
  './index.html',
  './styles.css',
  './script.js',
  './cat_voice.mp3',
  './capybara_voice.mp3',
  './openbox.png',
  './closebox.png',
  './cat.png',
  './capybara.png'
];

self.addEventListener('install', event => {
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then(cache => cache.addAll(urlsToCache))
  );
});

self.addEventListener('fetch', event => {
  event.respondWith(
    caches.match(event.request)
      .then(response => response || fetch(event.request))
  );
}); 